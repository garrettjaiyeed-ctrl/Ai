// AI Opportunity’s - simple interactions
(function(){
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const hamburger = document.getElementById('hamburger');
  const menu = document.getElementById('mobileMenu');

  if (hamburger && menu){
    hamburger.addEventListener('click', () => {
      const isOpen = hamburger.getAttribute('aria-expanded') === 'true';
      hamburger.setAttribute('aria-expanded', String(!isOpen));
      menu.hidden = isOpen;
    });

    menu.addEventListener('click', (e) => {
      // close after clicking a link
      if (e.target && e.target.tagName === 'A'){
        hamburger.setAttribute('aria-expanded', 'false');
        menu.hidden = true;
      }
    });
  }

  // Optional: animate "members and growing" number (purely cosmetic)
  const memberEl = document.getElementById('memberCount');
  if (memberEl){
    const target = parseInt(memberEl.textContent || '50', 10);
    let n = Math.max(1, Math.floor(target * 0.55));
    memberEl.textContent = String(n);
    const t = setInterval(() => {
      n += 1;
      memberEl.textContent = String(n);
      if (n >= target) clearInterval(t);
    }, 18);
  }
})();
